Trying to emulate Conti and Ryuk initial access vector

I want to make something like BazarLoader of IcedID.


It will be the initial access malware that can do a bit of recon, setup persistence, evade AV, and download CobaltStrike.

Maldocs in ISO, with the shortcut trick
- possible to do the rundll32 trick + macros in a real doc ? 

macro downloads and drops the dll for the loader and runs it with regsvr32
- downloads to `C:\Users\<username>\DLL` then copies it somewhere else, then setups up registry persistence

Calls back home over HTTPS to ensure connectivity and access

Then Cobalt strike dll is uploaded to the users machine over the initial access C2 channel


Delivery types:
xlsb
xlsm
zipped javascript
OneDrive link in an email to a zip with an iso.
	- LNK file masquerading as a document, once LNK is executed BazarLoader is run

































Links/Ideas:
https://unit42.paloaltonetworks.com/bazarloader-network-reconnaissance
