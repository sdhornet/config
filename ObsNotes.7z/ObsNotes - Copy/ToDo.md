#### Courses:
CodeAcademy Pro/Programming:
- C++
- Go
- C#
- Python3
- C
- nim

Sektor7:
- Malware Dev Beginner
- Malware Dev Intermediate
- Windows Evasion
- Windows Persistence 

OffSec:
- OSCP
- OSEP
	- Course, Videos, Labs, Exam

ZeroPoint  Sec:
- cRTO course w/lab, Exam
- C2 course

DarkVortex:
- Malware on steroids
- Red Team & Operational Security
- 
INE:
- Subscription

Pentester Academy:
- RTO AD Course

TCM:
- Practical Phishing
- OSINT
- Python101
- Movement, Pivoting, persistence
- PEH

TryHackMe:
- Subscription

HackTheBox:
- Subscription

Books:
 - A crap load