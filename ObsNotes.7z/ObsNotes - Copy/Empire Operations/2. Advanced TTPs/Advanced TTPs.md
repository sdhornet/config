### Advanced TTPs

Most users (and often threat actors) simply use the default settings. Modifying these will go a long way to ensuring that you trigger less alarms

Things we can modify easily:
- server default response
- server-agent comms
- stager methods/behavior

### Empire Agent Comms
- Agent request/response
	- Lots of pieces to modify

- Server Response
	- Default response page
	- Fingerprinting changes

#### Agents Request/Response

Several of these are exposed by default
- cookie
- profile
- headers
- useragent
- host
- port

DefaultProfile, Cookie, and Headers (server headers). useragent are some of the most meaningful changes, at the end can also put other headers

malleable_profiles help alot with modifying these values

in server/listeners/http.py line 176:
the default response is there, can modify this as well if you want to change the way it looks.

Can change Launcher if you don't want the indicators in there

### Bypasses
- Bypasses are used to disable common AV protections
- Default bypasses include:
	- Tal Liberman's AMSI bypass
	- Rasta Mouse AMSI bypass
	- Grabers AMI and ScriptBlock Logging bypass
	- ETW Bypass

#### Modifying Bypasses
- Default bypasses are located at /opt/Empire/empire/server/common/bypasses.py
- Modifying the bypasses here will be persistent across DC reset
- ETW is the easier to get past AV

in ~/empire/server/common/bypasses.py define a new function and use triple quotes to add the string into a format string

Add the line to get_default_bypasses at like 52 in ~/empire/server/database/defaults.py

Then need to reset the database

AMSI.fail
- Generates obfuscated AMSI bypasses in PowerShell
- Randomly selected and obfuscated
- No two bypasses have the same signatures

StarKiller also has some bypass management

### Advanced Stagers
#### Windows Macro Stager
- Tailor the stager to what the target is
- Our focus is Windows using a macro
	- Windows/macro
- Copy macro over to word
- Can be ran through macro-pack

#### Macro Stager
- Macro Stager is used for phishing to gain an initial foothold
- Phishing is still one of the primary means of initial compromise
- default is AutoClose but not as useful anymore

#### Macro Stager Modification
- The default Macro payload in Empire uses a very basic launcher method
- Lots of other options for launching payloads

Replay the last 2 lines of the VBA function, update the exec("...") with the correct variable name.
```
Set comApp = CreateObject("RDS.DataSpace")
comApp.CreateObject("Wscript.Shell", "").exec (EsD)
```

~/empire/server/stagers/windows/macro.py:
replace the 2 lines with these above with escape characters and it will make this part of the macro when it is generated.

- Links:
	- [OffensiveVBA](https://github.com/S3cur3Th1sSh1t/OffensiveVBA/blob/main/src/ShellWindows_Process_create.vba)
	- [Attack Surface Reduction](https://blog.sevagas.com/IMG/pdf/bypass_windows_defender_attack_surface_reduction.pdf)
	- [MacroPack_WMI](https://github.com/sevagas/macro_pack/blob/master/src/vbLib/WmiExec.py)
		- [MacroPack](https://github.com/sevagas/macro_pack)
	- [XLS Entanglement](https://github.com/BC-SECURITY/Offensive-VBA-and-XLS-Entanglement)
	- [EvilClippy](https://github.com/outflanknl/EvilClippy)

	- CactusTorch
	- Scarecrow
	- Ivy
	- MacroMe

### Plugins
- Extensions of Empire that allows for custom scripts and tools
- Similar (less capable) concept to Cobalt Strike's Aggressor scripts
- Can be accessed from the Empire Client or Starkiller

- Plugins can act as a interface between the Server and External Tool
- Written in Python 3
- Can load other applications as subprocesses
- Plugins can be controlled through the API

#### Plugin File Formatting
- Plugins are designated by .plugin
	- Technically Python3 code
- Plugins don't use YAMLs
- Info/options are outlined in the .plugin file.
- [Example](https://github.com/BC-SECURITY/Empire/blob/master/empire/server/plugins/example.plugin)

#### Example Plugin
[SOCKS Proxy Server plugin](https://github.com/BC-SECURITY/SocksProxyServer-Plugin)
- Creates a simple SOCKS Proxy server that can be controlled through Empire
- Pairs with Invoke-SocksProxy module
- Supports SOCKS 4/5

### Event-Based Architecture
- Plugins can react to events from the server
	- Method 1: Create a thread that loops infinitely and checks for changes
	- Method 2: Hooks, function registers and event and executed whatever once that event happens
		- [Hooks and Filters](https://bc-security.gitbook.io/empire-wiki/plugins/hooks-and-filters)

#### Event based example
[Twilio-plugin](https://github.com/BC-SECURITY/Twilio-Plugin)

#### Future of Plugins
- More event types
- Better defined API surface that is stable between minor Empire upgrades
- Enhance the current documentation to make it easier to get started

### Follow Along Exercise
- Goal: create a basic plugin that uses the embedded version of CrackMapExec in Kali

Create a copy of example.plugin and change the name to cme.plugin
in `self.info` make sure the name matches the name of the file

```python
self.info = {
                        'Name': 'cme',
                        'Author': ['@Cx01N'],
                        'Description': ('CrackMapExec (a.k.a CME) is a post-exploitation tool that helps automate '
                                        'assessing the security of large Active Directory networks.'),
                        'Software': 'S0488',
                        'Techniques': ['T1087', 'T1110', 'T1059', 'T1083', 'T1112', 'T1135', 'T1003', 'T1201', 'T1069',
                                       'T1018', 'T1053', '    T1082', 'T1016', 'T1049', 'T1550', 'T1047'],
                        'Comments': ['https://github.com/byt3bl33d3r/CrackMapExec'
                        ]
                    },
```

Can set the options for required options or setup a drop down menu or suggested values. Mainly for usability

```python
        self.options = {
            'Command': {
                'Description': 'Command to run in CME.',
                'Required': True,
                'Value': '--help'
            },
        }
```

- Execute - what the module does, change the function name to crackmapexec and remove the quotes in the () 

- Register - registers the plugin to the main menu object.
Set the class and self. to function name and the next definition should match as well

#### Running CME
- Three methods
	- Call crackmapexec directly
	- Generate a virtual env (poetry)
	- Integrate the project directly into Empire
		- from CrackMapExec.cme.crackmapexec import main

#### Kali Method:
```python
""" An example of a plugin. """
from __future__ import print_function

from empire.server.common.plugins import Plugin
import empire.server.common.helpers as helpers
import subprocess

# anything you simply write out (like a script) will run immediately when the
# module is imported (before the class is instantiated)
print("Hello from your new plugin!")


# this class MUST be named Plugin
class Plugin(Plugin):

    def onLoad(self):
        """
        Any custom loading behavior - called by init, so any
        behavior you'd normally put in __init__ goes here
        """
        print("Custom loading behavior happens now.")

        # you can store data here that will persist until the plugin
        # is unloaded (i.e. Empire closes)
        self.calledTimes = 0

        self.info = {
                        'Name': 'cme',
                        'Author': ['@hornet'],
                        'Description': ('CrackMapExec (a.k.a CME) is a post-exploitation tool that helps automate '
                                        'assessing the security of large Active Directory networks.'),
                        'Software': 'S0488',
                        'Techniques': ['T1087', 'T1110', 'T1059', 'T1083', 'T1112', 'T1135', 'T1003', 'T1201', 'T1069',
                                       'T1018', 'T1053', '    T1082', 'T1016', 'T1049', 'T1550', 'T1047'],
                        'Comments': ['https://github.com/byt3bl33d3r/CrackMapExec'
                                     ]
                    },

        # Any options needed by the plugin, settable during runtime
        self.options = {
            'Command': {
                'Description': 'Command to run in CME.',
                'Required': True,
                'Value': '--help'
            },
        }

    def execute(self, command):
        """
        Parses commands from the API
        """
        try:
            results = self.crackmapexec()
            return results
        except:
            return False

    def register(self, mainMenu):
        """
        Any modifications to the mainMenu go here - e.g.
        registering functions to be run by user commands
        """
        mainMenu.__class__.crackmapexec = self.crackmapexec

    def crackmapexec(self, args):
        """
        An example of a plugin function.
        Usage: test <start|stop> <message>
        """
        cme_cmd = ['crackmapexec', "--help"]
        self.cme_proc = subprocess.run(cme_cmd,
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE,
                                       bufsize=1,
                                       universal_newlines=True)
        self.mainMenu.plugin_socketio_message(self.info[0]['Name'], self.cme_proc.stdout)

    def shutdown(self):
        """
        Kills additional processes that were spawned
        """
        try:
            self.cme_proc.kill()
        except:
        # If the plugin spawns a process provide a shutdown method for when Empire exits else leave it as pass
            pass

```
