### Command and control
- Tools used to communicate with systems inside a compromised network
- Attempt to mimic normal traffic to avoid detection

Example:
- Empire
- Cobalt Strike
- Covenant
- Mythic

### C2 Threat Emulation
- Primary goal of C2s is threat emulation
- Characteristics:
	- Asynchronous
	- Survivability
	- Variable communication channels
	- Encrypted Communications
	- Flexibility

[Trellix Report](https://www.trellix.com/en-us/about/newsroom/stories/threat-labs/prime-ministers-office-compromised.html)

### Cobalt Strike
- Gold standard of C2 frameworks
- Used by industry and Governments
- Multi user/collaborative
- Malleable HTTP Listners
- Aggressor Scripts
- Expensive (3,500/user/year)

### Empire
- Powershell, Python, C#, and IronPython
- Multi-User / Collaborative
- Graphic Interface
- Malleable HTTP Listeners
- Plugins (Aggressor Scripts Lite)

### What is Empire?
Post-exploitation Framework built around PowerShell
- Merger of PowerShell Empire and Python EmPyre projects
- Runs on Python 3.8+
- Encrypted C2 channel
- Adaptable modules
	- bat, vbs, dll

### Empire Features
- Client-Server Architecture
	- Server: python
	- Client: PowerShell/Python
- Backed SQL database
	- Used for storing agents, listeners, creds
	- Everything is extensively logged
	- Tons of reports that can be created

### Empire Modularity:

![[Pasted image 20220128113920.png]]


### Empire's REST API:
- Controls Empire through HTTP JSON requests
- The API design is based on the BEEF Project
- Server can only be interacted with via the REST API
	- [Deathstar](https://github.com/byt3bl33d3r/DeathStar)
- Two Client Options:
	- Empire Client
	- Starkiller

[Documentation](https://bc-security.gitbook.io/empire-wiki/)

### Starkiller
- GUI that interacts with Empire through the API
- Multi-User support
	- User Management
	- Deconfliction
	- User reporting
- On-the-fly reporting
- Simplified Workflows

### Empire Client
- API based Empire CLI
- Features:
	- Supports multiple users
	- Custom agent shortcuts
	- Enhanced autocomplete options
	- Interactive shell screen

### Config YAMLs
- Empire has two configuration YAMLs
	- Server config.yaml
	- Client config.yaml
- Define start up actions and default settings

### Server Config.yaml
run pycharm and open server config.yaml

Defaults
- can update username/password need to change the client yaml as well
- staging-key can be random, but can be set as well
- obfuscate - turn on obfuscate for all modules, not launchers
- Obfuscate-command will be on by default if set to true, only works on powershell atm
	- C# also does some obfuscation with confuser, but python is broken right now
- Can white or black list certain IP addresses, will still call back but will stop execution during flask checkin.
- Retain-last-value: can keep the last value set on modules
- csharpserver starts on boot by default

`obfuscate-command: "Token\\command\\1,Token\\string\\1,Token\\whitespace\\1"`

to reset the database:
`./ps-empire server --reset` 

### Empire Main Menu
- use allows you to interact with server side stuff
- interact allows you to command agents on victim computer

### Listeners
- Configured flask servers that send and receive C2 data to agents on target machines
	- Define the comms profile and agent will use
	- http_com is using outlook com object
	- http using default http net web requests
- Can set to almost any port

Numerous configurations:
- HTTP
- Redirectors
- Hops - can be used for redirectors and apache servers
- Dropbox - Walkthrough on wiki, could be broken 
- OneDrive
- Malleable HTTP

### Stagers
- a small "payload" which can be either manually triggered or implemented elsewhere
- Can be through of as a downlaod cradle
- Stagers are written in several different languages
	- PowerShell
	- Python
	- C# (limited)
	- IronPython (limited) agents

### Staged vs Stageless
- staged:
	- Payloads are broken into smaller chunks that can be loaded in a serialized method

- Stageless
	- All code is sent over at the same time and loads the agent
		- C# Agent exe is stageless

Multiple stages to deploy the entire agent:
![[Pasted image 20220128130111.png]]


### Agents
- Individual interactable instances running on target machine
- Info displays:
	- Hosts IP
	- Machine Name
	- Username
	- Process
	- Language

### Listeners
- Listeners are the server side of Empire
- Runs a flask server that receives connections from the target machine and are used to control agents.
- Agent always reaches back to the server - aka beacons out.

#### HTTP Listener
- Runs an HTTP or HTTPs client server
	- Windows will not allow self signed certs by default
- Runs on port 80 by default
- Listener is compatible with PowerShell, Python, IronPython, or C#
	- C# agent will not work with a self signed cery
- Uses GET/POST messages to send information

### Stagers
Stagers lay the groundwork for Empire activities, many languages and formats:
- VBS
- BAT
- Ducky Script
- Executable
- Shellcode
- DLL

#### Multi-Launcher Stager
- Provides a one-liner that can be used in either PowerShell or Python
- Simplest stager to use
	- Other download cradles to use 

#### Executable
- Empire has integrated a modified version of Roslyn .NET compiler to generate executable on the fly.
- Support languages:
	- C#
	- IronPython
	- PowerShell
	- bypasses only work on PowerShell

#### Shellcode
- Created position-independent shellcode
- Uses Donut to generate the shellcode from an executable created by the Roslyn .NET compiler
In stagers under server can do AMSI bypasses here

### Exercise - Deploy agent
### Malleable Listeners
- Uselistener http_malleable
- most of the ingestion doesn't work, but will take all comms traffic 

### JA3/S Sigs
https://www.bc-security.org/post/ja3-s-signatures-and-how-to-avoid-them/
- http.py in server/listeners can change cypherlist to breack JA3 hashing

### Agents:
- Agents are the empire implant that are responsible for executing tasks and initiating communication to the server for check-ins
	- Firewalls usually block incoming traffic to a network so agents reach "out"
	- Run in memory

#### PowerShell Agents
- PowerShell provides an easy to use scripting language that has full access to the Win32 API
	- Monitored in many places now a days
	- PowerShell still makes up for a large percentage of CyberAttacks

#### Python Agent
- Updated version of Empire's original python2 agent
- Requires target to have Python 3 installed
- Most functionality is focused on Linux based machines
- Smaller library of modules

#### C# Agent
- Empire's "modern" implant
- The server utilizes Covenant's Roslyn Compiler to compile .NET assemblies and send back to the agent
- Agent supports Covenant grunt taskings to promote interoperability
- Capable of running PS taskings or launching a PS agent

#### IronPython Agent
- Modified python agent, compatible with IronPython 3
- EXE/Shellcode contains all needed DLLs and Libraries
	- Does not require IronPython to be installed
- IronPython3 spin-off of IronNetInjector
- Can run some Python modules
	- Adding C# and PowerShell module compatibility 
- Shell runs PowerShell

### Agent Management 
- KillDate - Stop an agent on a specific date
- Sleep - Set the agents delay and jitter settings
	- Jitter - max percentage change that can be applied to dely
	- Delay - time interval between checkins in seconds
- Workinghours - Hours during the dat that the agent is active
- Update_comms - Dynamically updates agent comms to a new listener
- Rename - Rename the agent

### Shell
can run shell for get a sudo interactive shell on the target agent
- either bash or powershell depending on the agent

Should be able to into it in starkiller also need to investigate

### Shortcuts:
![[Pasted image 20220128151011.png]]

### Client YAML
Defines defaults for the client - starkiller or the cli
Servers - default and additional servers to connect to
Shortcuts - predefined commands to run for agent interaction
Empire/client/config.yaml can quickly switch between different servers
Have shortcuts in here to customize what you want certain commands to shortcut to

### Modules
usemodule allows us run almost 400 modules
Cool one is invoke_bof and download any bof and use it.
set File -p to get a popup can also move it to Empire/empire/client/downloads

## Server Management
### Obfuscation
- Empire used Invoke-Obfuscation to obfuscate PowerShell
- Admin Menu commands:
	- Obfuscate all outgoing powershell commands
	- Obfuscate Command Updates the default Invoke-Obfuscation command to run on modules
- Keyword_obfuscation - Can pick keywords to change


### File Management
- Empire hosts file server for allowing multiple operators to share files
- Files are stored in the Downloads folder
	- Upload
	- Download
- Some modules allow files to be used these are uploaded to the server during execution

> TIP: -p to get a pop-up to select the file

### User Management
User management can be done in starkiller or empire client
Options:
- Create user
- enable/disable
- Userlist

### Reporting
- Every agent has its own file structure for files, screenshots and logs
`/Empire/server/downloads/<agent_name>`

### Report Generation
- Produces 3 types of reports
	- sessions.csv
	- credentials.csv
	- master.log
- Execute from the Admin menu
- Reports are located at /Empire/data

### Plugins
- lite cobalt strike aggressor scripts
- Cab be loaded with nearly anything
Examples:
- Eternal Blue
- Nmap
- Enhanced Reporting
- MITRE ATT&CK Emulation
- Socks Proxy Server
- Chisel Server

### Obfuscations
In agent:
set Obfuscate True
set ObfuscateCommand `"Token\command\1,Token\command\2,Token\string\1,Token\string\2,Token\string\1,Token\whitespace\1,Token\whitespace\1"`

