### What is OSINT?
Open source intelligence is a multi-methods methodology for collecting, analyzing, and making decisions about data accessible in publicly available sources to be used in an intelligence context. In the intelligence community, the term open refers to overt, publicly available sources.

#### Intelligence Lifecycle

1) Planning and Direction
	1) Who, what, when, where, why
2) Collection
	1) actually gathering all the data
3) Processing and Exploitation
	1) About taking the data and interpreter/process it
4) Analysis and Production
	1) Analyze data and put into intellectual form (report)
5) Dissemination and Integration
	1) Present data to client 