### Why this course?
- Improve research skillset and methodology
- Gain a better understanding of OSINT techniques
- Personal OPSEC

