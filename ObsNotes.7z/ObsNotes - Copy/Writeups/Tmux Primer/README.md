# Tmux Primer
### Why Tmux
Tmux is a terminal multiplexer, which means it allows for a persistent terminal session over a non persistent connection, like SSH. It also allows for better multi-tasking and terminal organization by means of windows and panes.

### Installation
Standard install for an apt package:
`sudo apt-get install tmux -y`

### Custom Conf
I use a custom conf that changes the tmux pre-fix key (the keybind used before a tmux command). Default is Ctrl+b, however, this is not comfortable to press.

- Create a new file in the users folder called ".tmux.conf"
- Paste the below text into this file
- Next time tmux is run, it will use this configuration
	- **_Tmux prefix is changed to Ctrl+a_** 
	- Also sets the history to 10000
	- enables vi mode for searching 
	- when a new pane is created it launches in the same path 
		- default behavior is to reset home dir
  
```
#Remap prefix to screens
set -g prefix C-a
bind C-a send-prefix
unbind C-b

#QoL Stuff
set -g history-limit 10000
set -g allow-rename off

#join Windows
bind-key j command-prompt -p "join pane from:" "join-pane -s '%%'"
bind-key s command-prompt -p "send pane to:" "join-pane -t '%%'"

#Search Mode VI
set-window-option -g mode-keys vi

set -g @plugin 'tmux-plugins/tmux-logging'

#trying to set same directory for split/new windows, delete is this messes stuff up

bind '"' split-window -v -c "#{pane_current_path}"
bind % split-window -h -c "#{pane_current_path}"
bind c new-window -c "#{pane_current_path}"
```

### Sessions
To get started with a new tmux session, you can just type `tmux`
If you would like to name the session: `tmux new -s sessionname`

To disconnect from the session: `Ctrl+a d`
To list sessions: `tmux ls`
To connect to an existing session: `tmux a -t sessionname`
To connect to the last session: `tmux a`

### Windows
Once in a tmux session, you will automatically create a window.
The session name is included in the brackets, while the window name defaults to 0:bash, which is just the program that window is running.
![[Pasted image 20211202145046.png]]

To change the window name: `Ctrl+a ,`, then type a new name, press enter

![[Pasted image 20211202145557.png]]

To create a new window: `Ctrl+a c`

The 0 is the window number, you can switch between windows with: `Ctrl + (number)`, the asterisk next to the window name denotes the active window. 

![[Pasted image 20211202145750.png]]

### Panes
Panes are a way to subdivide a window. My common setup is either 4 panes or 2/1 setup 

![[Pasted image 20211202151419.png]]

![[Pasted image 20211202151439.png]]

This allows for multiple tools to be run simultaneously, IE responder + relay, or having a tool output in one pane, while referencing it for another tool.

To split a window horizontally: `Ctrl+a "`
To split a window vertically: `Ctrl+a %`
To zoom into a pane and have it take up the whole screen: `Ctrl+a z`, same command to return to the original layout
To close a pane or window `exit`

To move your cursor between panes: `Ctrl+a (arrow key)` in the direction of the pane you want to move to

There are various other commands such as resizing, moving panes left/right, send commands to all panes. Please visit the Cheatsheet in [[README#References]].

### Copy mode
Copy mode is a way to scroll up through the buffer, search up or down through it, copy sections of the pane into the buffer.

To enter copy mode: `Ctrl+a [`, the top right corner of the pane will display the current buffer position/total buffer lines.

To scroll up, use the up arrow, to go the to top use: `g`
To scroll down, use the down arrow, to go to the bottom use: `G`

To search backwards through the buffer use: `?`
To search forwards through the buffer use: `/`

Pressing `n` will take you to the next occurrence of your search term, `N` will take you to the previous one. 

To start selecting text from the buffer, press `space` and highlight required text, then `enter` to copy the selection

To paste the buffer `Ctrl+a ]`

### Conclusion
Those are all the commands I use day to day to organize my terminal sessions and ensure they persist through connection failures, closing SSH sessions, and generally trying to stay organized. Let me know if you have any questions, the Youtube video linked below goes into more depth on the various features. The cheetsheat is a reference for the above commands and some more nuanced ones.

### References:
[Youtube Tutorial](https://www.youtube.com/watch?v=Lqehvpe_djs)
[Cheatsheet](https://tmuxcheatsheet.com/)