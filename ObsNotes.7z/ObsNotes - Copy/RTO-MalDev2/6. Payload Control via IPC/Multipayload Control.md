There can be situations when payload is executed may times concurrently.

Having too many sessions or running payloads can be bad if generating too many artifacts on system/network

Want to have control how many payloads are run

Control is achieved with shared object whose existence means payload is already in the memory and all new payloads cease execution. 

control objects - mutex, event, semaph, named pipes, file on disk, reg keys etc

payload will set a global sync on first run, subsequent runs will first check if this object is active. If false it will run the payload, if true it will exit without running the payload

