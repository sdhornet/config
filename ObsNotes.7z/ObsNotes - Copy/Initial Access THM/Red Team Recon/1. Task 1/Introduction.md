#### The tasks of this room cover the following topics:

-   Types of reconnaissance activities
-   WHOIS and DNS-based reconnaissance
-   Advanced searching
-   Searching by image
-   Google Hacking
-   Specialized search engines
-   Recon-ng
-   Maltego

#### Some specific objectives we'll cover include:

-   Discovering subdomains related to our target company
-   Gathering publicly available information about a host and IP addresses
-   Finding email addresses related to the target
-   Discovering login credentials and leaked passwords
-   Locating leaked documents and spreadsheets

Reconnaissance can be broken down into two parts — passive reconnaissance and active reconnaissance, as explained in Task 2. In this room, we will be focusing on passive reconnaissance, i.e., techniques that don’t alert the target or create 'noise'. In later rooms, we will use active reconnaissance tools that tend to be noisy by nature.